package com.cybage.model;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name="userrole")
public class UserRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	//bi-directional many-to-one association to Role
	@ManyToOne
	@JoinColumn(name="ROLEID")
	private Role role;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="USERID")
	private User user;

	public UserRole() {
	}

	public UserRole(String id, Role role, User user) {
		super();
		this.id = id;
		this.role = role;
		this.user = user;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "UserRole [id=" + id + ", role=" + role + ", user=" + user + "]";
	}

}