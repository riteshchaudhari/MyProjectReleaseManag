package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;


@Entity
@Table(name="iterationitems")
public class IterationItem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	//bi-directional many-to-one association to Iteration
	@ManyToOne
	@JoinColumn(name="ITERATIONID", referencedColumnName = "ID")
	private Iteration iteration;

	//bi-directional many-to-one association to Item
	@ManyToOne
	@JoinColumn(name="ITEMID", referencedColumnName = "ID")
	private Item item;

	public IterationItem() {
	}
	
	public IterationItem(String id, Iteration iteration, Item item) {
		super();
		this.id = id;
		this.iteration = iteration;
		this.item = item;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Iteration getIteration() {
		return this.iteration;
	}

	public void setIteration(Iteration iteration) {
		this.iteration = iteration;
	}

	public Item getItem() {
		return this.item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "IterationItem [id=" + id + ", iteration=" + iteration + ", item=" + item + "]";
	}

}