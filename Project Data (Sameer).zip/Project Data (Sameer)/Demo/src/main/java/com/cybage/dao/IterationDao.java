package com.cybage.dao;

import com.cybage.model.Iteration;
import com.cybage.model.IterationLog;
import com.cybage.model.ReleaseIteration;

public interface IterationDao {
	
	Iteration addIteration(ReleaseIteration releaseIteration, IterationLog iterationLog);
	Iteration updateIteration(Iteration iteration, IterationLog iterationLog);
	Iteration deleteIterationById(String id);
	Iteration deleteItertion(Iteration iteration);
}
