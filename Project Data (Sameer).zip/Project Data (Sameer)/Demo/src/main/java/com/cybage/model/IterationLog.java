package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name="iterationlog")
public class IterationLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	
	//bi-directional many-to-one association to Iteration
	@ManyToOne
	@JoinColumn(name="ITERATIONID", referencedColumnName = "ID")
	private Iteration iteration;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="MODIFIEDDT")
	private Date modifiedDate;
	
	@Column(name="MODIFIEDBY", length=36)
	private String modifiedBy;

	public IterationLog() {
	}

	public IterationLog(String id, Iteration iteration, Date modifiedDate, String modifiedBy) {
		super();
		this.id = id;
		this.iteration = iteration;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Iteration getIteration() {
		return this.iteration;
	}

	public void setIteration(Iteration iteration) {
		this.iteration = iteration;
	}

	@Override
	public String toString() {
		return "IterationLog [id=" + id + ", iteration=" + iteration + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + "]";
	}

}