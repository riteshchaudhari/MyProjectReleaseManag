package com.cybage.utility;

import java.util.UUID;

public class Utility {
	
	public static String getUUID() {
		return UUID.randomUUID().toString();
	}
	
}
