-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.73-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema releasemanagement
--

CREATE DATABASE IF NOT EXISTS releasemanagement;
USE releasemanagement;

--
-- Definition of table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `CREATEDDT` datetime NOT NULL,
  `CREATEDBY` char(36) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `items`
--

/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;


--
-- Definition of table `itemslog`
--

DROP TABLE IF EXISTS `itemslog`;
CREATE TABLE `itemslog` (
  `ID` char(36) NOT NULL,
  `ITEMID` char(36) DEFAULT NULL,
  `MODIFIEDDT` datetime DEFAULT NULL,
  `MODIFIEDBY` char(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ITEMID_LOG_FK_idx` (`ITEMID`),
  CONSTRAINT `ITEMID_LOG_FK` FOREIGN KEY (`ITEMID`) REFERENCES `items` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `itemslog`
--

/*!40000 ALTER TABLE `itemslog` DISABLE KEYS */;
/*!40000 ALTER TABLE `itemslog` ENABLE KEYS */;


--
-- Definition of table `iteration`
--

DROP TABLE IF EXISTS `iteration`;
CREATE TABLE `iteration` (
  `ID` char(36) NOT NULL,
  `TITLE` varchar(45) NOT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `STARTDT` datetime NOT NULL,
  `ENDDT` datetime DEFAULT NULL,
  `STATUSID` char(36) NOT NULL,
  `TYPEID` char(36) NOT NULL,
  `CREATEDDT` datetime NOT NULL,
  `CREATEDBY` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TITLE_UNIQUE` (`TITLE`),
  KEY `ITERATION_STATUS_FK_idx` (`STATUSID`),
  KEY `ITERATION_TYPE_FK_idx` (`TYPEID`),
  CONSTRAINT `ITERATION_STATUS_FK` FOREIGN KEY (`STATUSID`) REFERENCES `iterationstatus` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ITERATION_TYPE_FK` FOREIGN KEY (`TYPEID`) REFERENCES `iterationtype` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iteration`
--

/*!40000 ALTER TABLE `iteration` DISABLE KEYS */;
/*!40000 ALTER TABLE `iteration` ENABLE KEYS */;


--
-- Definition of table `iterationitems`
--

DROP TABLE IF EXISTS `iterationitems`;
CREATE TABLE `iterationitems` (
  `ID` char(36) NOT NULL,
  `ITERATIONID` char(36) NOT NULL,
  `ITEMID` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `ITERATION_FK_idx` (`ITERATIONID`),
  KEY `ITERATION_ITEM_FK_idx` (`ITEMID`),
  CONSTRAINT `ITERATION_FK` FOREIGN KEY (`ITERATIONID`) REFERENCES `iteration` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ITERATION_ITEM_FK` FOREIGN KEY (`ITEMID`) REFERENCES `items` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iterationitems`
--

/*!40000 ALTER TABLE `iterationitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `iterationitems` ENABLE KEYS */;


--
-- Definition of table `iterationlog`
--

DROP TABLE IF EXISTS `iterationlog`;
CREATE TABLE `iterationlog` (
  `ID` char(36) NOT NULL,
  `ITERATIONID` char(36) DEFAULT NULL,
  `MODIFIEDDT` datetime DEFAULT NULL,
  `MODIFIEDBY` char(36) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ITERATIONID_LOG_FK_idx` (`ITERATIONID`),
  CONSTRAINT `ITERATIONID_LOG_FK` FOREIGN KEY (`ITERATIONID`) REFERENCES `iteration` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iterationlog`
--

/*!40000 ALTER TABLE `iterationlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `iterationlog` ENABLE KEYS */;


--
-- Definition of table `iterationstatus`
--

DROP TABLE IF EXISTS `iterationstatus`;
CREATE TABLE `iterationstatus` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iterationstatus`
--

/*!40000 ALTER TABLE `iterationstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `iterationstatus` ENABLE KEYS */;


--
-- Definition of table `iterationtype`
--

DROP TABLE IF EXISTS `iterationtype`;
CREATE TABLE `iterationtype` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iterationtype`
--

/*!40000 ALTER TABLE `iterationtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `iterationtype` ENABLE KEYS */;


--
-- Definition of table `release`
--

DROP TABLE IF EXISTS `release`;
CREATE TABLE `release` (
  `ID` char(36) NOT NULL,
  `TITLE` varchar(45) NOT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `STARTDT` datetime NOT NULL,
  `PLANNEDDT` datetime NOT NULL,
  `RELEASEDT` datetime DEFAULT NULL,
  `TYPEID` char(36) NOT NULL,
  `TOID` char(36) NOT NULL,
  `STATUSID` char(36) NOT NULL,
  `MANAGERID` char(36) NOT NULL,
  `VERSION` int(3) DEFAULT '1',
  `CREATEDDT` datetime NOT NULL,
  `CREATEDBY` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TITLE_UNIQUE` (`TITLE`),
  KEY `TYPE_idx` (`TYPEID`),
  KEY `TO_FK_idx` (`TOID`),
  KEY `STATUS_FK_idx` (`STATUSID`),
  KEY `MANAGERID_FK_idx` (`MANAGERID`),
  CONSTRAINT `MANAGERID_FK` FOREIGN KEY (`MANAGERID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `RELEASE_STATUS_FK` FOREIGN KEY (`STATUSID`) REFERENCES `releasestatus` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `RELEASE_TO_FK` FOREIGN KEY (`TOID`) REFERENCES `releaseto` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `RELEASE_TYPE_FK` FOREIGN KEY (`TYPEID`) REFERENCES `releasetype` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `release`
--

/*!40000 ALTER TABLE `release` DISABLE KEYS */;
/*!40000 ALTER TABLE `release` ENABLE KEYS */;


--
-- Definition of table `releaseitems`
--

DROP TABLE IF EXISTS `releaseitems`;
CREATE TABLE `releaseitems` (
  `ID` char(36) NOT NULL,
  `RELEASEID` char(36) NOT NULL,
  `ITEMID` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `RELEASE_FK_idx` (`RELEASEID`),
  KEY `ITEM_FK_idx` (`ITEMID`),
  CONSTRAINT `ITEM_FK` FOREIGN KEY (`ITEMID`) REFERENCES `items` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RELEASE_FK` FOREIGN KEY (`RELEASEID`) REFERENCES `release` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `releaseitems`
--

/*!40000 ALTER TABLE `releaseitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `releaseitems` ENABLE KEYS */;


--
-- Definition of table `releaseiteration`
--

DROP TABLE IF EXISTS `releaseiteration`;
CREATE TABLE `releaseiteration` (
  `ID` char(36) NOT NULL,
  `RELEASEID` char(36) NOT NULL,
  `ITERATIONID` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `RELEASEID_FK_idx` (`RELEASEID`),
  KEY `ITERATIONID_FK_idx` (`ITERATIONID`),
  CONSTRAINT `ITERATIONID_FK` FOREIGN KEY (`ITERATIONID`) REFERENCES `iteration` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `RELEASEID_FK` FOREIGN KEY (`RELEASEID`) REFERENCES `release` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `releaseiteration`
--

/*!40000 ALTER TABLE `releaseiteration` DISABLE KEYS */;
/*!40000 ALTER TABLE `releaseiteration` ENABLE KEYS */;


--
-- Definition of table `releaselog`
--

DROP TABLE IF EXISTS `releaselog`;
CREATE TABLE `releaselog` (
  `ID` char(36) NOT NULL,
  `RELEASEID` char(36) NOT NULL,
  `MODIFIEDDT` datetime NOT NULL,
  `MODIFIEDBY` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `RELEASEID_LOG_FK_idx` (`RELEASEID`),
  CONSTRAINT `RELEASEID_LOG_FK` FOREIGN KEY (`RELEASEID`) REFERENCES `release` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `releaselog`
--

/*!40000 ALTER TABLE `releaselog` DISABLE KEYS */;
/*!40000 ALTER TABLE `releaselog` ENABLE KEYS */;


--
-- Definition of table `releasestatus`
--

DROP TABLE IF EXISTS `releasestatus`;
CREATE TABLE `releasestatus` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME_UNIQUE` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `releasestatus`
--

/*!40000 ALTER TABLE `releasestatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `releasestatus` ENABLE KEYS */;


--
-- Definition of table `releaseto`
--

DROP TABLE IF EXISTS `releaseto`;
CREATE TABLE `releaseto` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME_UNIQUE` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `releaseto`
--

/*!40000 ALTER TABLE `releaseto` DISABLE KEYS */;
/*!40000 ALTER TABLE `releaseto` ENABLE KEYS */;


--
-- Definition of table `releasetype`
--

DROP TABLE IF EXISTS `releasetype`;
CREATE TABLE `releasetype` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME_UNIQUE` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `releasetype`
--

/*!40000 ALTER TABLE `releasetype` DISABLE KEYS */;
/*!40000 ALTER TABLE `releasetype` ENABLE KEYS */;


--
-- Definition of table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `ID` char(36) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME_UNIQUE` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`ID`,`NAME`) VALUES 
 ('77c92c62-1165-4cf1-a459-ea35315490bb','Manager');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;


--
-- Definition of table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `ID` char(36) NOT NULL,
  `USERID` char(36) NOT NULL,
  `ROLEID` char(36) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `USERID_FK_idx` (`USERID`),
  KEY `ROLEID_FK_idx` (`ROLEID`),
  CONSTRAINT `ROLEID_FK` FOREIGN KEY (`ROLEID`) REFERENCES `roles` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `USERID_FK` FOREIGN KEY (`USERID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userrole`
--

/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` (`ID`,`USERID`,`ROLEID`) VALUES 
 ('ccbae9aa-3347-492d-a701-23e45671dfd2','246d60e2-7a70-4b8e-8774-b893952dd888','77c92c62-1165-4cf1-a459-ea35315490bb');
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;


--
-- Definition of table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `ID` char(36) NOT NULL,
  `FIRSTNAME` varchar(45) NOT NULL,
  `LASTNAME` varchar(45) DEFAULT NULL,
  `EMAIL` varchar(60) NOT NULL,
  `PASSWORD` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EMAIL_UNIQUE` (`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`ID`,`FIRSTNAME`,`LASTNAME`,`EMAIL`,`PASSWORD`) VALUES 
 ('246d60e2-7a70-4b8e-8774-b893952dd888','UserFirst','User Last','user@gmail.com','userPassword');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
